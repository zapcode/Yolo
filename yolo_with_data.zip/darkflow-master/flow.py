#! /usr/bin/env python

import sys
from darkflow.cli import cliHandler


ll = ['flow.py', '--model', 'cfg/tiny-yolo-dr.cfg', '--train', '--dataset', r'C:\Users\acer\Desktop\images\im', '--annotation', r'C:\Users\acer\Desktop\images\ana']
cliHandler(ll)

